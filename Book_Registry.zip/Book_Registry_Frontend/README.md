
Install react-router-dom, axios, and bulma by typing the following command in the terminal:
##	`npm i react-router-dom axios bulma`

Install react-datepicker component
##	`npm  install react-datepicker --save`

In the project directory, you can run:
### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.