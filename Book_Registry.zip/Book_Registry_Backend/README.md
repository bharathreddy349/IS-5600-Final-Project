
Install express, mongoose and cors by typing the following command in the terminal:
##	`npm i express mongoose cors`

Install nodemon globally by typing the following command in the terminal:
##	`npm i -g nodemon`

In the project directory, you can run:
### `nodemon index`